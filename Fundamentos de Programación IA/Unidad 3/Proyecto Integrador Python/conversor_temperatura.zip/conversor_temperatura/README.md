# Conversor de temperaturas

Ejemplo integrador de la Unidad 3 (Fundamentos de Programación, IAD-2413).
Convierte temperaturas entre grados Celsius y Fahrenheit.

## Requisitos
- Python 3.10 o superior

## Instalación
No requiere dependencias externas (solo usa la biblioteca estándar `math`).

## Ejecución
```bash
python src/conversor.py
```

## Pruebas
```bash
python -m unittest discover tests
```

## Autor
Ejemplo desarrollado para el curso Fundamentos de Programación — ITD / TecNM.
