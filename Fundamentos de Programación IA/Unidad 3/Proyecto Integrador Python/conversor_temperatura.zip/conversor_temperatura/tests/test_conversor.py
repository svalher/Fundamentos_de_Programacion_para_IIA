import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from conversor import celsius_a_fahrenheit, fahrenheit_a_celsius


class TestConversor(unittest.TestCase):

    def test_celsius_a_fahrenheit_cero(self):
        self.assertEqual(celsius_a_fahrenheit(0), 32.0)

    def test_celsius_a_fahrenheit_valor_positivo(self):
        self.assertEqual(celsius_a_fahrenheit(24), 75.2)

    def test_fahrenheit_a_celsius_valor_conocido(self):
        self.assertEqual(fahrenheit_a_celsius(75.2), 24.0)

    def test_conversion_de_ida_y_vuelta(self):
        original = 30
        ida_y_vuelta = fahrenheit_a_celsius(celsius_a_fahrenheit(original))
        self.assertAlmostEqual(ida_y_vuelta, original, delta=0.1)


if __name__ == "__main__":
    unittest.main()
