"""
Conversor de temperaturas
Ejemplo integrador de la Unidad 3 (IAD-2413).

Usa el módulo estándar `math` (3.2) para redondear el resultado,
vive dentro de una estructura de proyecto organizada (3.3),
y se pensó para depurarse paso a paso con el IDE (3.1).
"""

import math


def celsius_a_fahrenheit(celsius):
    """Convierte grados Celsius a Fahrenheit, redondeado a 2 decimales."""
    fahrenheit = (celsius * 9 / 5) + 32
    return math.floor(fahrenheit * 100) / 100


def fahrenheit_a_celsius(fahrenheit):
    """Convierte grados Fahrenheit a Celsius, redondeado a 2 decimales."""
    celsius = (fahrenheit - 32) * 5 / 9
    return math.floor(celsius * 100) / 100


def celsius_a_kelvin(celsius):
    """Convierte grados Celsius a Kelvin, redondeado a 2 decimales."""
    kelvin = celsius + 273.15
    return math.floor(kelvin * 100) / 100


if __name__ == "__main__":
    temperatura = 24
    resultado = celsius_a_fahrenheit(temperatura)
    print(f"{temperatura}°C equivalen a {resultado}°F")
