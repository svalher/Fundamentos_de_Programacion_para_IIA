import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class ConversorTest {

    @Test
    public void celsiusAFahrenheit_cero_devuelveTreintaYDos() {
        assertEquals(32.0, Conversor.celsiusAFahrenheit(0), 0.0001);
    }

    @Test
    public void celsiusAFahrenheit_valorPositivo_devuelveSetentaYCincoPuntoDos() {
        assertEquals(75.2, Conversor.celsiusAFahrenheit(24), 0.0001);
    }

    @Test
    public void fahrenheitACelsius_valorConocido_devuelveVeinticuatro() {
        assertEquals(24.0, Conversor.fahrenheitACelsius(75.2), 0.0001);
    }

    @Test
    public void celsiusAKelvin_cero_devuelveDoscientosSetentaYTresPuntoQuince() {
        assertEquals(273.15, Conversor.celsiusAKelvin(0), 0.0001);
    }
}
