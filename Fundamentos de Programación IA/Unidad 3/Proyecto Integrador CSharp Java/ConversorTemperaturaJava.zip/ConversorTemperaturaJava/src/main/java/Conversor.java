/**
 * Conversor de temperaturas.
 * Ejemplo integrador de la Unidad 3 (IAD-2413).
 *
 * Usa la biblioteca estándar java.lang.Math (3.2) para redondear el resultado,
 * vive dentro de una estructura de proyecto organizada estilo Maven (3.3),
 * y se pensó para depurarse paso a paso con el IDE (3.1).
 */
public class Conversor {

    public static double celsiusAFahrenheit(double celsius) {
        double fahrenheit = (celsius * 9 / 5) + 32;
        return Math.round(fahrenheit * 100.0) / 100.0;
    }

    public static double fahrenheitACelsius(double fahrenheit) {
        double celsius = (fahrenheit - 32) * 5 / 9;
        return Math.round(celsius * 100.0) / 100.0;
    }

    public static double celsiusAKelvin(double celsius) {
        double kelvin = celsius + 273.15;
        return Math.round(kelvin * 100.0) / 100.0;
    }

    public static void main(String[] args) {
        double temperatura = 24;
        double resultado = celsiusAFahrenheit(temperatura);
        System.out.println(temperatura + "\u00b0C equivalen a " + resultado + "\u00b0F");
    }
}
