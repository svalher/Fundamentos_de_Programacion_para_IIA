# Conversor de temperaturas (Java)

Ejemplo integrador de la Unidad 3 (Fundamentos de Programación, IAD-2413).
Convierte temperaturas entre grados Celsius, Fahrenheit y Kelvin.

## Requisitos
- JDK 17 o superior
- Maven (para compilar y ejecutar las pruebas con `mvn`)

## Ejecución
```bash
javac -d target src/main/java/Conversor.java
java -cp target Conversor
```

## Pruebas (con Maven)
```bash
mvn test
```

## Autor
Ejemplo desarrollado para el curso Fundamentos de Programación — ITD / TecNM.
