# Conversor de temperaturas (C#)

Ejemplo integrador de la Unidad 3 (Fundamentos de Programación, IAD-2413).
Convierte temperaturas entre grados Celsius, Fahrenheit y Kelvin.

## Requisitos
- .NET SDK 8.0 o superior

## Ejecución
```bash
dotnet run --project ConversorTemperatura.csproj
```

## Pruebas
```bash
dotnet test Tests/Tests.csproj
```

## Autor
Ejemplo desarrollado para el curso Fundamentos de Programación — ITD / TecNM.
