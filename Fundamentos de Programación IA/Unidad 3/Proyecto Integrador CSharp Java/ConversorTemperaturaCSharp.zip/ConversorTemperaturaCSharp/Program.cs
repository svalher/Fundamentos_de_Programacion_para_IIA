// Conversor de temperaturas
// Ejemplo integrador de la Unidad 3 (IAD-2413).
//
// Usa la biblioteca estándar System (3.2) para redondear el resultado,
// vive dentro de una estructura de proyecto organizada (3.3),
// y se pensó para depurarse paso a paso con el IDE (3.1).

using System;

namespace ConversorTemperatura
{
    public class Conversor
    {
        public static double CelsiusAFahrenheit(double celsius)
        {
            double fahrenheit = (celsius * 9 / 5) + 32;
            return Math.Round(fahrenheit, 2);
        }

        public static double FahrenheitACelsius(double fahrenheit)
        {
            double celsius = (fahrenheit - 32) * 5 / 9;
            return Math.Round(celsius, 2);
        }

        public static double CelsiusAKelvin(double celsius)
        {
            double kelvin = celsius + 273.15;
            return Math.Round(kelvin, 2);
        }

        public static void Main(string[] args)
        {
            double temperatura = 24;
            double resultado = CelsiusAFahrenheit(temperatura);
            Console.WriteLine($"{temperatura}\u00b0C equivalen a {resultado}\u00b0F");
        }
    }
}
