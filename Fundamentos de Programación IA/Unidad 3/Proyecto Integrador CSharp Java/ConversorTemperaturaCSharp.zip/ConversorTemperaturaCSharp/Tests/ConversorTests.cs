using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConversorTemperatura;

namespace ConversorTemperatura.Tests
{
    [TestClass]
    public class ConversorTests
    {
        [TestMethod]
        public void CelsiusAFahrenheit_Cero_DevuelveTreintaYDos()
        {
            Assert.AreEqual(32.0, Conversor.CelsiusAFahrenheit(0));
        }

        [TestMethod]
        public void CelsiusAFahrenheit_ValorPositivo_DevuelveSetentaYCincoPuntoDos()
        {
            Assert.AreEqual(75.2, Conversor.CelsiusAFahrenheit(24));
        }

        [TestMethod]
        public void FahrenheitACelsius_ValorConocido_DevuelveVeinticuatro()
        {
            Assert.AreEqual(24.0, Conversor.FahrenheitACelsius(75.2));
        }

        [TestMethod]
        public void CelsiusAKelvin_Cero_DevuelveDoscientosSetentaYTresPuntoQuince()
        {
            Assert.AreEqual(273.15, Conversor.CelsiusAKelvin(0));
        }
    }
}
