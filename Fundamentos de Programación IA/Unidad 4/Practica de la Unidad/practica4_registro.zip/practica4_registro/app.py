from flask import Flask, render_template, request

app = Flask(__name__)


@app.route("/")
def inicio():
    """Muestra el formulario de registro."""
    return render_template("formulario.html")


@app.route("/registro", methods=["POST"])
def registro():
    """Recibe los datos del formulario y muestra la página de perfil."""
    nombre = request.form.get("nombre")
    correo = request.form.get("correo")
    carrera = request.form.get("carrera")

    return render_template(
        "perfil.html",
        nombre=nombre,
        correo=correo,
        carrera=carrera
    )


if __name__ == "__main__":
    app.run(debug=True)
